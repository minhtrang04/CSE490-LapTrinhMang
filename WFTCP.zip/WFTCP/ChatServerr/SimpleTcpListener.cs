﻿namespace ChatServerr
{
    internal class SimpleTcpListener
    {
    }
}