﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Net.Sockets;
using SimpleTCP;
using System.Threading;

namespace ChatServerr
{
    public partial class FormServer : Form
    {
        Socket socket;
        IPEndPoint ipEndPoint;
        IPAddress iPAddress;
        NetworkStream stream;
        byte[] msg;
        TcpClient client;// Doi tuong TcpClient de quan ly ket noi cua client
        TcpListener listener;// Doi tuong TcpListener de lang nghe ket noi tu client
        private Thread thread;
        Boolean accept = false;
        public FormServer()
        {
            InitializeComponent();
            socket = new Socket(SocketType.Stream,ProtocolType.Tcp);
        }
        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                // Doc dia chi IP va Port tu TextBox
                iPAddress = IPAddress.Parse(txtIPAServer.Text);
                int port = int.Parse(txtPortServer.Text);

                // Khoi tao server va bat dau lang nghe ket noi
                listener = new TcpListener(iPAddress, port);
                listener.Start();

                thread = new Thread(AcceptClient);
                thread.Start();
                accept = true;

                txtChatBoardServer.AppendText("Server started...\r\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi : " + ex.Message);
            }
        }
        private void AcceptClient()
        {
            try
            {
                client = listener.AcceptTcpClient();
                stream = client.GetStream();
                while (accept)
                {
                        //nhận message
                        msg = new byte[4069];
                        stream.Read(msg, 0, msg.Length);
                        string receivmssg = Encoding.UTF8.GetString(msg);

                    //hiển thị message
                    // Cập nhật giao diện người dùng từ thread phụ
                    this.Invoke((MethodInvoker)delegate
                    {
                        this.txtChatBoardServer.AppendText("\r\nClient: " + receivmssg.ToString()+"\r\n");
                    });
                }
            }
            catch(Exception ex) 
            {
                MessageBox.Show("Lỗi : " + ex.Message);
            }
        }
       
        private void btnSendServer_Click(object sender, EventArgs e)
        {
            try
            {
                if (client.Connected)
                {
                    byte[] msg = Encoding.UTF8.GetBytes(this.txtSendServer.Text);
                    stream.Write(msg, 0, msg.Length);
                    this.Invoke((MethodInvoker)delegate
                    {
                        txtChatBoardServer.AppendText("\r\nYou: " + this.txtSendServer.Text + "\r\n");
                    });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi : " + ex.Message);
            }
        }
        private void btnStop_Click(object sender, EventArgs e)
        {
            try
            {
                accept = false;
                thread.Abort();
                listener.Stop();
                txtChatBoardServer.AppendText("Server stopped.\r\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi : " + ex.Message);
            }
        }

        private void FormServer_FormClosing(object sender, FormClosingEventArgs e)
        {
           
        }

        private void FormServer_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Application.Exit();
            FormServer f = new FormServer();
            f.Close();

        }
    }
}
