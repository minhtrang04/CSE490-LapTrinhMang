﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Net.Sockets;
using SimpleTCP;
using System.Threading;

namespace ChatClient
{
    public partial class FormClient : Form
    {
        Socket socket;
        IPEndPoint ipEndPoint;
        IPAddress iPAddress;
        NetworkStream stream;
        byte[] msg;
        TcpClient client;// Doi tuong TcpClient de quan ly ket noi cua client
        private Thread thread;
        Boolean listen = false;
        public FormClient()
        {
            InitializeComponent();
        }

        private void btnSendClient_Click(object sender, EventArgs e)
        {
            if (client.Connected)
            {
                stream = client.GetStream();
               byte[] mssg = Encoding.UTF8.GetBytes(this.txtSendClient.Text) ;
                stream.Write(mssg, 0, mssg.Length);
                //hiển thị message
                this.Invoke((MethodInvoker)delegate
                {
                    this.txtChatBoardClient.AppendText("\r\n You: " + this.txtSendClient.Text + "\r\n");
                });
            }
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                // Doc dia chi IP va Port tu TextBox
                iPAddress = IPAddress.Parse(txtIPAClient.Text);
                int port = int.Parse(txtPortClient.Text);

                // Khoi tao server va bat dau lang nghe ket noi
                client = new TcpClient();
                client.Connect(iPAddress,port);

                if (client.Connected)
                {
                    stream = client.GetStream();
                    msg = Encoding.UTF8.GetBytes("");
                    stream.Write(msg, 0, msg.Length);
                    thread = new Thread(Listening);
                    thread.Start();
                    listen = true;
                }
                txtChatBoardClient.AppendText("Client started...\r\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi : " + ex.Message);
            }
        }
        private void Listening()
        {
            try
            {
                while (listen)
                {
                    //nhận message
                    msg = new byte[4069];
                    stream.Read(msg, 0, msg.Length);
                    string receivmsg = Encoding.UTF8.GetString(msg);

                    //hiển thị message
                    this.Invoke((MethodInvoker)delegate
                    {
                        this.txtChatBoardClient.AppendText("\r\n Server: "+receivmsg.ToString()+"\r\n");
                    });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi : " + ex.Message);
            }
        }
        private void FormClient_FormClosing(object sender, FormClosingEventArgs e)
        {
            
        }

        private void FormClient_FormClosed(object sender, FormClosedEventArgs e)
        {
            FormClient f = new FormClient();
            f.Close();
           // Application.Exit();
        }
    }
}
