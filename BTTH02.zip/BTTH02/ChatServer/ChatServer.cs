﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Threading;

namespace ChatServer
{
    public partial class ChatServer : Form
    {
        Socket socket;
        IPEndPoint ipEndPoint;
        IPAddress iPAddress;
        NetworkStream stream;
        byte[] msg;

        TcpClient client;// Doi tuong TcpClient de quan ly ket noi cua client
        TcpListener listener;// Doi tuong TcpListener de lang nghe ket noi tu client
        private Thread thread;
        Boolean accept = false;
        private Dictionary<string, TcpClient> connectedClients = new Dictionary<string, TcpClient>(); // Lưu danh sách client

        public ChatServer()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                // Doc dia chi IP va Port tu TextBox
                iPAddress = IPAddress.Parse(txtIPAServer.Text);
                int port = 5000;

                // Khoi tao server va bat dau lang nghe ket noi
                listener = new TcpListener(iPAddress, port);
                listener.Start();

                thread = new Thread(AcceptClient);
                thread.Start();
                accept = true;

                ChatBoard.AppendText("Server started...\r\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi : " + ex.Message);
            }
        }

        // Chấp nhận client kết nối và bắt đầu giao tiếp
        private void AcceptClient()
        {
            while (accept)
            {
                try
                {
                    client = listener.AcceptTcpClient();
                    stream = client.GetStream();
                    string clientName = client.Client.RemoteEndPoint.ToString();

                    connectedClients.Add(clientName, client);

                    // Cập nhật danh sách client trên giao diện server
                    this.Invoke((MethodInvoker)delegate
                    {
                        listBox1.Items.Add(clientName);
                        ChatBoard.AppendText($"{clientName} đã kết nối.\r\n");
                    });

                    // Khởi tạo luồng để xử lý từng client
                    Thread clientThread = new Thread(() => HandleClient(client, clientName));
                    clientThread.Start();
                    BroadcastClientList();

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi: " + ex.Message);
                }
            }
        }


        private void HandleClient(TcpClient client, string clientName)
        {
            NetworkStream stream = client.GetStream();

            try
            {
                while (true)
                {
                    // Đọc dữ liệu từ client
                    byte[] buffer = new byte[4096];
                    int bytesRead = stream.Read(buffer, 0, buffer.Length);
                    if (bytesRead == 0) break; // Client ngắt kết nối

                    string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                    if (message.StartsWith("FILE_TRANSFER"))
                    {
                        // Tách header để lấy thông tin file
                        string[] headerParts = message.Split('|');
                        if (headerParts.Length == 3)
                        {
                            string fileName = headerParts[1];
                            long fileSize = long.Parse(headerParts[2]);

                            this.Invoke((MethodInvoker)delegate
                            {
                                ChatBoard.AppendText($"Đang nhận file '{fileName}' ({fileSize} bytes) từ {clientName}...\r\n");
                            });

                            // Nhận file
                            ReceiveFile(stream, fileName, fileSize);
                        }
                    }
                    else
                    {
                        // Hiển thị tin nhắn từ client lên giao diện server
                        this.Invoke((MethodInvoker)delegate
                        {
                            ChatBoard.AppendText($"{clientName}: {message}\r\n");
                        });
                    }
                    // Phản hồi lại Client
                    string response = $"Server received: {message}";
                    byte[] data = Encoding.UTF8.GetBytes(response);
                    stream.Write(data, 0, data.Length);
                }
            }
            catch
            {
                // Xử lý khi client ngắt kết nối
                this.Invoke((MethodInvoker)delegate
                {
                    listBox1.Items.Remove(clientName);
                    ChatBoard.AppendText($"{clientName} đã ngắt kết nối.\r\n");
                });

                connectedClients.Remove(clientName);
                BroadcastClientList();

            }
        }
        private void ReceiveFile(NetworkStream stream, string fileName, long fileSize)
        {
            string savePath = Path.Combine("ReceivedFiles", fileName);
            Directory.CreateDirectory("ReceivedFiles"); // Tạo thư mục nếu chưa có

            using (FileStream fs = new FileStream(savePath, FileMode.Create, FileAccess.Write))
            {
                byte[] buffer = new byte[4096];
                long totalBytesRead = 0;

                while (totalBytesRead < fileSize)
                {
                    int bytesRead = stream.Read(buffer, 0, buffer.Length);
                    if (bytesRead == 0) break; // Dừng khi nhận hết dữ liệu

                    fs.Write(buffer, 0, bytesRead);
                    totalBytesRead += bytesRead;
                }
            }

            this.Invoke((MethodInvoker)delegate
            {
                ChatBoard.AppendText($"File '{fileName}' đã được lưu tại {savePath}.\r\n");
            });
        }
        // Gửi danh sách client đến tất cả client đang kết nối
        private void SendClientList()
        {
            string clientList = string.Join(",", connectedClients.Keys); // Danh sách client dạng chuỗi
            byte[] data = Encoding.UTF8.GetBytes("CLIENT_LIST:" + clientList);

            foreach (var client in connectedClients.Values)
            {
                NetworkStream stream = client.GetStream();
                stream.Write(data, 0, data.Length);
            }
        }
        private void BroadcastMessage(string message, string sender)
        {
            // Gửi tin nhắn đến tất cả client ngoại trừ người gửi
            foreach (var client in connectedClients)
            {
                if (client.Key != sender)
                {
                    NetworkStream stream = client.Value.GetStream();
                    byte[] data = Encoding.UTF8.GetBytes(message);
                    stream.Write(data, 0, data.Length);
                }
            }
        }
        private void BroadcastClientList()
        {
            string clientList = string.Join(",", connectedClients.Keys); // Danh sách client dạng chuỗi
            byte[] data = Encoding.UTF8.GetBytes("CLIENT_LIST:" + clientList);

            foreach (var client in connectedClients.Values)
            {
                try
                {
                    NetworkStream stream = client.GetStream();
                    stream.Write(data, 0, data.Length);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi : " + ex.Message);
                }
            }
        }



        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                // Gửi tin nhắn từ server đến client được chọn
                string selectedClient = listBox1.SelectedItem?.ToString();
                if (selectedClient != null && connectedClients.ContainsKey(selectedClient))
                {
                    string message = txtSend.Text;
                    NetworkStream stream = connectedClients[selectedClient].GetStream();

                    byte[] data = Encoding.UTF8.GetBytes($"Server: {message}");
                    stream.Write(data, 0, data.Length);

                    ChatBoard.AppendText($"Server gửi đến {selectedClient}: {message}\r\n");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi : " + ex.Message);
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnImport_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog.FileName;

                if (File.Exists(filePath))
                {
                    try
                    {
                        FileInfo fileInfo = new FileInfo(filePath);
                        string fileName = fileInfo.Name;
                        long fileSize = fileInfo.Length;

                        string header = $"FILE_TRANSFER|{fileName}|{fileSize}";
                        byte[] headerData = Encoding.UTF8.GetBytes(header + "\n");
                        stream.Write(headerData, 0, headerData.Length);

                        byte[] fileData = File.ReadAllBytes(filePath);
                        stream.Write(fileData, 0, fileData.Length);
                        this.Invoke((MethodInvoker)delegate
                        {
                            ChatBoard.AppendText($"File '{fileName}' sent successfully.");
                        });
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Failed to send file: {ex.Message}");
                    }
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {

            try
            {
                // Ngừng nhận kết nối mới
                accept = false;
                listener?.Stop();

                // Đóng tất cả các kết nối với client
                foreach (var client in connectedClients.Values)
                {
                    client?.Close();
                }

                connectedClients.Clear();

                // Thoát luồng nhận kết nối
                if (thread != null && thread.IsAlive)
                {
                    thread.Join(); // Chờ luồng hoàn tất
                }

                // Cập nhật giao diện
                listBox1.Items.Clear();
                ChatBoard.AppendText("Server đã dừng.\r\n");

                // Vô hiệu hóa các nút không cần thiết
                btnStart.Enabled = true;
                btnClose.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi dừng server: " + ex.Message);
            }
        }
    }
}