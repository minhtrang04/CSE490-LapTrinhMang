﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChatClient
{
    public partial class ChatClient : Form
    {
        Socket socket;
        IPAddress iPAddress;
        NetworkStream stream;// Dùng để gửi và nhận dữ liệu
        byte[] msg;// Mảng byte dùng để chứa thông điệp gửi và nhận.
        TcpClient client;// Kết nối đến server
        private Thread listenerThread; // Luồng lắng nghe tin nhắn từ server
        Boolean listen = false;
        public ChatClient()
        {
            InitializeComponent();
        }


        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                // Kiểm tra xem client và stream đã được khởi tạo chưa
                if (client == null || !client.Connected || stream == null)
                {
                    MessageBox.Show("Chưa kết nối đến server. Vui lòng kết nối lại.");
                    return;
                }

                // Lấy NetworkStream từ TcpClient
                stream = client.GetStream();

                // Mã hóa thông điệp thành byte
                byte[] mssg = Encoding.UTF8.GetBytes(this.txtSend.Text);

                // Gửi thông điệp qua stream
                stream.Write(mssg, 0, mssg.Length);

                // Hiển thị message lên giao diện
                this.Invoke((MethodInvoker)delegate
                {
                    this.ChatBoard.AppendText("\r\n You: " + this.txtSend.Text + "\r\n");
                });

                // Xóa nội dung trong TextBox sau khi gửi
                this.txtSend.Clear();
            }
            catch (Exception ex)
            {
                // Hiển thị thông báo lỗi nếu có vấn đề xảy ra
                MessageBox.Show("Lỗi khi gửi tin nhắn: " + ex.Message);
            }
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                // Doc dia chi IP va Port tu TextBox
                iPAddress = IPAddress.Parse(txtIPServer.Text);
                int port = 5000;

                // Khoi tao server va bat dau lang nghe ket noi
                client = new TcpClient();
                client.Connect(iPAddress, port);

                if (client.Connected)
                {
                    stream = client.GetStream();
                    //msg = Encoding.UTF8.GetBytes("");
                    //stream.Write(msg, 0, msg.Length);

                    // Tạo luồng để lắng nghe tin nhắn từ server.
                    // Chạy luồng lắng nghe tin nhắn từ server
                    listenerThread = new Thread(ReceiveMessages);
                    listenerThread.Start();
                    listen = true;// Bắt đầu lắng nghe.
                }
                ChatBoard.AppendText("Client started...\r\n");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi : " + ex.Message);
            }
        }
        private void ReceiveMessages()
        {
            try
            {
                while (listen)
                {
                    msg = new byte[4069]; // Tạo buffer để nhận dữ liệu từ server.
                    int bytesRead = stream.Read(msg, 0, msg.Length);

                    if (bytesRead > 0)
                    {
                        string receivedMessage = Encoding.UTF8.GetString(msg, 0, bytesRead);

                        // Kiểm tra nếu tin nhắn là danh sách client
                        if (receivedMessage.StartsWith("CLIENT_LIST:"))
                        {
                            string clientList = receivedMessage.Substring("CLIENT_LIST:".Length);
                            string[] clients = clientList.Split(',');

                            // Cập nhật danh sách client lên giao diện
                            this.Invoke((MethodInvoker)delegate
                            {
                                listBox1.Items.Clear();
                                foreach (var client in clients)
                                {
                                    listBox1.Items.Add(client);
                                }
                            });
                        }
                        if (receivedMessage.StartsWith("FILE_TRANSFER"))
                        {
                            ReceiveFile(stream, receivedMessage);
                        }
                        else
                        {
                            // Hiển thị các tin nhắn khác
                            this.Invoke((MethodInvoker)delegate
                            {
                                ChatBoard.AppendText(receivedMessage + "\r\n");
                            });
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi : " + ex.Message);
                Disconnect();
            }
        }
        private void ReceiveFile(NetworkStream stream, string header)
        {
            try
            {
                // Tách header để lấy thông tin file
                string[] headerParts = header.Split('|');
                if (headerParts.Length < 3)
                {
                    MessageBox.Show("Header nhận file không hợp lệ.");
                    return;
                }

                string fileName = headerParts[1];
                long fileSize = long.Parse(headerParts[2]);

                // Tạo thư mục lưu file nhận được
                string saveDirectory = Path.Combine(Application.StartupPath, "ReceivedFiles");
                if (!Directory.Exists(saveDirectory))
                {
                    Directory.CreateDirectory(saveDirectory);
                }

                string savePath = Path.Combine(saveDirectory, fileName);

                // Bắt đầu nhận file
                byte[] buffer = new byte[4096];
                long totalBytesReceived = 0;

                using (FileStream fs = new FileStream(savePath, FileMode.Create, FileAccess.Write))
                {
                    while (totalBytesReceived < fileSize)
                    {
                        int bytesRead = stream.Read(buffer, 0, buffer.Length);
                        if (bytesRead == 0)
                        {
                            break;
                        }

                        fs.Write(buffer, 0, bytesRead);
                        totalBytesReceived += bytesRead;

                        // Cập nhật giao diện hoặc thông báo tiến độ nếu cần
                        this.Invoke((MethodInvoker)delegate
                        {
                            ChatBoard.AppendText($"Đang nhận file: {totalBytesReceived}/{fileSize} bytes...\r\n");
                        });
                    }
                }

                // Kiểm tra hoàn tất nhận file
                if (totalBytesReceived == fileSize)
                {
                    this.Invoke((MethodInvoker)delegate
                    {
                        ChatBoard.AppendText($"File '{fileName}' đã được nhận thành công và lưu tại: {savePath}\r\n");
                    });
                }
                else
                {
                    MessageBox.Show("Quá trình nhận file bị gián đoạn.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi nhận file: {ex.Message}");
            }
        }

        private void Disconnect()
        {
            try
            {
                if (stream != null)
                {
                    stream.Close();
                    stream = null;
                }

                if (client != null)
                {
                    client.Close();
                    client = null;
                }

                this.Invoke((MethodInvoker)delegate
                {
                    ChatBoard.AppendText("Đã ngắt kết nối với server.\r\n");
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi đóng kết nối: " + ex.Message);
            }
        }

        private void btnImport_Click(object sender, EventArgs e)
{
    if (client == null || !client.Connected)
    {
        MessageBox.Show("Chưa kết nối tới server.");
        return;
    }

    OpenFileDialog openFileDialog = new OpenFileDialog();
    if (openFileDialog.ShowDialog() == DialogResult.OK)
    {
        string filePath = openFileDialog.FileName;

        if (File.Exists(filePath))
        {
            try
            {
                FileInfo fileInfo = new FileInfo(filePath);
                string fileName = fileInfo.Name;
                long fileSize = fileInfo.Length;

                // Tạo header để thông báo tên file và kích thước
                string header = $"FILE_TRANSFER|{fileName}|{fileSize}";
                byte[] headerData = Encoding.UTF8.GetBytes(header + "\n");
                stream.Write(headerData, 0, headerData.Length);

                // Gửi dữ liệu file
                byte[] fileData = File.ReadAllBytes(filePath);
                stream.Write(fileData, 0, fileData.Length);

                this.Invoke((MethodInvoker)delegate
                {
                    ChatBoard.AppendText($"File '{fileName}' đã được gửi tới server.\r\n");
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi gửi file: {ex.Message}");
            }
        }
    }
}

    }
}
